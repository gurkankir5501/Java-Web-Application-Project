package Model;

public class siparisModel {

	 private int siparisKodu;
	 private String siparisTarihi ; 
	 
	 private String odemeTipi;
	 private String uyekullaniciAdi;
	 
	 
	 
	 



	


	public String getUyekullaniciAdi() {
		return uyekullaniciAdi;
	}





	public void setUyekullaniciAdi(String uyekullaniciAdi) {
		this.uyekullaniciAdi = uyekullaniciAdi;
	}





	public siparisModel(int siparisKodu, String siparisTarihi, String odemeTipi, String uyekullaniciAdi) {
		
		this.siparisKodu = siparisKodu;
		this.siparisTarihi = siparisTarihi;
		
		this.odemeTipi = odemeTipi;
		this.uyekullaniciAdi = uyekullaniciAdi;
	}


	


	public siparisModel(String siparisTarihi,
			String odemeTipi, String uyekullaniciAdi) {
		super();
		this.siparisTarihi = siparisTarihi;
		
		this.odemeTipi = odemeTipi;
		this.uyekullaniciAdi = uyekullaniciAdi;
	}





	public siparisModel(int siparisKodu, String siparisTarihi, String odemeTipi) {
		super();
		this.siparisKodu = siparisKodu;
		this.siparisTarihi = siparisTarihi;
		
		this.odemeTipi = odemeTipi;
	}


	public int getSiparisKodu() {
		return siparisKodu;
	}


	public void setSiparisKodu(int siparisKodu) {
		this.siparisKodu = siparisKodu;
	}


	public String getSiparisTarihi() {
		return siparisTarihi;
	}


	public void setSiparisTarihi(String siparisTarihi) {
		this.siparisTarihi = siparisTarihi;
	}


	

	public String getOdemeTipi() {
		return odemeTipi;
	}


	public void setOdemeTipi(String odemeTipi) {
		this.odemeTipi = odemeTipi;
	}



	 
	 
	
	
     
     
}
